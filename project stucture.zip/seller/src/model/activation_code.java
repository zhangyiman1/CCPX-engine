package model;

public class activation_code {
	private int Seller_id;
	private String Activation_Code;
	
	public int getSeller_id() {
		return Seller_id;
	}
	public void setSeller_id(int Seller_id) {
		this.Seller_id = Seller_id;
	}
	
	public String getActivation_Code() {
		return Activation_Code;
	}
	public void setActivation_Code(String Activation_Code) {
		this.Activation_Code = Activation_Code;
	}
	
}
