package model;

public class industry_type {
	private int Industry_id;
	private String Industry_Name;
	private String IndustryType_Logo;
	
	public int getIndustry_id() {
		return Industry_id;
	}
	public void setIndustry_id(int Industry_id) {
		this.Industry_id= Industry_id;
	}
	
	public String getIndustry_Name() {
		return Industry_Name;
	}
	public void setIndustry_Name(String Industry_Name) {
		this.Industry_Name = Industry_Name;
	}
	
	public String getIndustryType_Logo() {
		return IndustryType_Logo;
	}
	public void setIndustryType_Logo(String IndustryType_Logo) {
		this.IndustryType_Logo = IndustryType_Logo;
	}

}
